#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sympy import symbols, simplify, apart

z = symbols('z')

X_z = 2 + (4*z/(z-1) - z/(z-0.5))

# Αποσύνθεση της συνάρτησης X(z)
X_inv_z = apart(X_z)

# Απλοποίηση της αντίστροφης συνάρτησης
X_inv_z = simplify(X_inv_z)

print("Ο αντίστροφος μετασχηματισμός X(z) είναι:")
print(X_inv_z)


# In[ ]:




