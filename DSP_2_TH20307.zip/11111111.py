#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
def x(t):
    return 6 - 2 * np.cos(600 * np.pi * t) + 6 * np.cos(1600 * np.pi * t) + 6 * np.cos(1000 * np.pi * t) - 0.5 * np.cos(4000 * np.pi * t)
T = 2 * np.pi / 600 
print("Περίοδος T του σήματος:", T)
t = np.linspace(0, 2 * T, 1000)

x_t = x(t)

plt.figure(figsize=(10, 5))
plt.plot(t, x_t, label='Αναλογικό Σήμα $x(t)$')
plt.title('Αναλογικό Σήμα $x(t)$ στο Διάστημα [0, 2Τ]')
plt.xlabel('Χρόνος (s)')
plt.ylabel('Πλάτος')
plt.legend()
plt.grid(True)
plt.show()
# Υπολογισμός των συχνοτήτων στο σήμα
frequencies = [600, 1600, 1000, 4000]
max_frequency = max(frequencies)

F_Nyquist = 2 * max_frequency
print(" F_Nyquist:", F_Nyquist)
# Εφαρμογή δειγματοληψίας
t_sampled = np.linspace(0, 2 * T, 200)
x_sampled = x(t_sampled)

plt.figure(figsize=(10, 5))
plt.plot(t, x_t, label='Αναλογικό Σήμα $x(t)$', color='blue')
plt.stem(t_sampled, x_sampled, label='Δειγματοληπτημένο Σήμα', linefmt='r-', markerfmt='ro', basefmt='gray', use_line_collection=True)
plt.title('Δειγματοληπτημένο Σήμα με $F_{Nyquist}$')
plt.xlabel('Χρόνος (s)')
plt.ylabel('Πλάτος')
plt.legend()
plt.grid(True)
plt.show()


# In[ ]:




