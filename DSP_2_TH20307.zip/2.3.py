#!/usr/bin/env python
# coding: utf-8

# In[10]:


def z_transform(x, n_values):
    z_transformed = 0
    for i in range(len(x)):
        z_transformed += x[i] * (1/z)**n_values[i]
    return z_transformed

# x[n]
x_values = [1, 1, 1]  
n_values = [-1, 1, 2]  

#μετασχηματισμός Z
z = symbols('z')
X_z = z_transform(x_values, n_values)
print("Ο μετασχηματισμός Z του σήματος x[n] είναι:", X_z)



# In[ ]:




