#!/usr/bin/env python
# coding: utf-8

# In[9]:


from sympy import symbols, cos, pi, solve

z = symbols('z')

a = z**2 - 1.7*cos(16*pi)*z + 0.6

# Υπολογισμός των ριζών του παρονομαστή
roots = solve(a, z)

# Έλεγχος αν οι ρίζες βρίσκονται μέσα στον μοναδιαίο κύκλο
for root in roots:
    if abs(root) < 1:
        print("Η ρίζα", root, "βρίσκεται εντός του μοναδιαίου κύκλου.")
    else:
        print("Η ρίζα", root, "βρίσκεται εκτός του μοναδιαίου κύκλου.")



# In[ ]:




